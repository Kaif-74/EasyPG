from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from pgs.models import PG, PGImage
from pgs.forms import PGForm
from rooms.models import Room
from rooms.forms import RoomForm
from accounts.forms import ProfileForm
from django.contrib import messages

@login_required
def dashboard_home(request):
    my_pgs = PG.objects.filter(owner=request.user).order_by('-created_at')
    return render(request, 'dashboard/home.html', {'pgs': my_pgs})

@login_required
def profile_settings(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('dashboard_home')
    else:
        form = ProfileForm(instance=profile)
    return render(request, 'dashboard/profile.html', {'form': form})

@login_required
def add_pg(request):
    if request.method == 'POST':
        form = PGForm(request.POST, request.FILES)
        if form.is_valid():
            pg = form.save(commit=False)
            pg.owner = request.user
            pg.save()
            messages.success(request, "PG added successfully!")
            return redirect('dashboard_home')
    else:
        form = PGForm()
    return render(request, 'dashboard/add_pg.html', {'form': form})

@login_required
def edit_pg(request, pg_id):
    pg = get_object_or_404(PG, id=pg_id, owner=request.user)
    if request.method == 'POST':
        form = PGForm(request.POST, request.FILES, instance=pg)
        if form.is_valid():
            form.save()
            messages.success(request, f"Successfully updated {pg.name}")
            return redirect('dashboard_home')
    else:
        form = PGForm(instance=pg)
    return render(request, 'dashboard/edit_pg.html', {'form': form, 'pg': pg})

@login_required
def delete_pg(request, pg_id):
    pg = get_object_or_404(PG, id=pg_id, owner=request.user)
    if request.method == 'POST':
        pg.delete()
        messages.success(request, "Property deleted successfully.")
        return redirect('dashboard_home')
    return render(request, 'dashboard/confirm_delete.html', {'item': pg, 'type': 'PG'})

# --- PG GALLERY MANAGEMENT ---

@login_required
def manage_pg_images(request, pg_id):
    pg = get_object_or_404(PG, id=pg_id, owner=request.user)
    if request.method == 'POST':
        images = request.FILES.getlist('images') # Get multiple files
        for img in images:
            PGImage.objects.create(pg=pg, image=img)
        messages.success(request, "Images uploaded successfully!")
        return redirect('manage_pg_images', pg_id=pg.id)
    
    images = pg.images.all()
    return render(request, 'dashboard/manage_pg_images.html', {'pg': pg, 'images': images})

@login_required
def delete_pg_image(request, image_id):
    image = get_object_or_404(PGImage, id=image_id, pg__owner=request.user)
    pg_id = image.pg.id
    image.delete()
    messages.success(request, "Image removed.")
    return redirect('manage_pg_images', pg_id=pg_id)

# --- ROOM MANAGEMENT ---

@login_required
def manage_rooms(request, pg_id):
    pg = get_object_or_404(PG, id=pg_id, owner=request.user)
    rooms = Room.objects.filter(pg=pg)
    return render(request, 'dashboard/manage_rooms.html', {'pg': pg, 'rooms': rooms})

@login_required
def add_room(request, pg_id):
    pg = get_object_or_404(PG, id=pg_id, owner=request.user)
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            room = form.save(commit=False)
            room.pg = pg
            room.availability_status = 'Available' if room.vacant_beds > 0 else 'Fully Occupied'
            room.save()
            messages.success(request, f"Room {room.room_number} added successfully!")
            return redirect('manage_rooms', pg_id=pg.id)
    else:
        form = RoomForm()
    return render(request, 'dashboard/add_room.html', {'form': form, 'pg': pg})

@login_required
def edit_room(request, room_id):
    room = get_object_or_404(Room, id=room_id, pg__owner=request.user)
    if request.method == 'POST':
        form = RoomForm(request.POST, instance=room)
        if form.is_valid():
            room = form.save(commit=False)
            room.availability_status = 'Available' if room.vacant_beds > 0 else 'Fully Occupied'
            room.save()
            messages.success(request, f"Room {room.room_number} updated.")
            return redirect('manage_rooms', pg_id=room.pg.id)
    else:
        form = RoomForm(instance=room)
    return render(request, 'dashboard/edit_room.html', {'form': form, 'room': room})

@login_required
def delete_room(request, room_id):
    room = get_object_or_404(Room, id=room_id, pg__owner=request.user)
    pg_id = room.pg.id
    if request.method == 'POST':
        room.delete()
        messages.success(request, "Room deleted.")
        return redirect('manage_rooms', pg_id=pg_id)
    return render(request, 'dashboard/confirm_delete.html', {'item': room, 'type': 'Room'})

@login_required
def update_vacancy(request, room_id):
    room = get_object_or_404(Room, id=room_id, pg__owner=request.user)
    if request.method == 'POST':
        vacant = request.POST.get('vacant_beds')
        room.vacant_beds = int(vacant)
        room.availability_status = 'Available' if room.vacant_beds > 0 else 'Fully Occupied'
        room.save()
        messages.success(request, f"Vacancy updated for Room {room.room_number}")
        return redirect('manage_rooms', pg_id=room.pg.id)
    return render(request, 'dashboard/update_vacancy.html', {'room': room})